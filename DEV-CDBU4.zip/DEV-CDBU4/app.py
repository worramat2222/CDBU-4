from flask import Flask, render_template, request, redirect, url_for, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId
import os

# Initialize Flask app
app = Flask(__name__)

# MongoDB connection
MONGO_URI = "mongodb://localhost:27017/inventory_db"
client = MongoClient(MONGO_URI)
db = client.inventory_db

# Routes
@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/products')
def products():
    page = request.args.get('page', 1, type=int)
    per_page = 8  # จำนวนสินค้าต่อหน้า
    total_products = db.products.count_documents({})
    products = list(db.products.find().skip((page - 1) * per_page).limit(per_page))

    pagination = {
        'page': page,
        'per_page': per_page,
        'total': total_products,
        'has_prev': page > 1,
        'has_next': page * per_page < total_products,
        'prev_num': page - 1 if page > 1 else None,
        'next_num': page + 1 if page * per_page < total_products else None,
        'iter_pages': list(range(1, (total_products // per_page) + 2))
    }

    return render_template('products.html', products=products, pagination=pagination)

@app.route('/add-product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        code = request.form['code']
        quantity = int(request.form['quantity'])
        cost_center = request.form['cost_center']  # รับข้อมูล Cost Center

        # Handle image upload
        image = request.files.get('image')
        if image:
            image_path = f"static/images/{image.filename}"
            image.save(image_path)
        else:
            image_path = "static/images/default.png"  # Default image if none uploaded

        db.products.insert_one({
            'name': name,
            'code': code,
            'quantity': quantity,
            'cost_center': cost_center  # บันทึก Cost Center ลงฐานข้อมูล
        })
        return redirect(url_for('products'))

    return render_template('add_product.html')

@app.route('/withdraw/<id>', methods=['GET', 'POST'])
def withdraw(id):
    try:
        print(f"[DEBUG] Received ID: {id}")  # Debugging ID
        if not ObjectId.is_valid(id):
            print("[ERROR] Invalid ObjectId")
            return "Invalid Product ID!", 400

        product = db.products.find_one({'_id': ObjectId(id)})
        if not product:
            print("[ERROR] Product not found in database")
            return "Product not found!", 404

        error_message = None

        if request.method == 'POST':
            try:
                quantity = request.form.get('quantity')
                line = request.form.get('line')
                employee_id = request.form.get('employee_id')
                employee_name = request.form.get('employee_name')
                group = request.form.get('group')
                date = request.form.get('date')

                if not all([quantity, line, employee_id, employee_name, group, date]):
                    error_message = "Please fill in all fields."
                    print("[ERROR] Missing form data")
                    return render_template('withdraw.html', product=product, error_message=error_message)

                quantity = int(quantity)
                if product['quantity'] >= quantity:
                    db.products.update_one({'_id': ObjectId(id)}, {'$inc': {'quantity': -quantity}})
                    db.withdrawals.insert_one({
                        'product_id': id,
                        'product_name': product['name'],
                        'quantity': quantity,
                        'line': line,
                        'employee_id': employee_id,
                        'employee_name': employee_name,
                        'group': group,
                        'date': date
                    })
                    print("[INFO] Withdrawal successful")
                    return redirect(url_for('history'))  # Redirect to history after withdrawal
                else:
                    error_message = "Not enough stock!"
                    print("[ERROR] Not enough stock")

            except ValueError:
                error_message = "Invalid input. Please check your data."
                print("[ERROR] Invalid input")

        return render_template('withdraw.html', product=product, error_message=error_message)

    except Exception as e:
        print(f"[ERROR] An exception occurred: {str(e)}")
        return f"An error occurred: {str(e)}", 500

@app.route('/history')
def history():
    withdrawals = list(db.withdrawals.find())
    for withdrawal in withdrawals:
        product = db.products.find_one({'_id': ObjectId(withdrawal['product_id'])})
        if product:
            withdrawal['part_number'] = product.get('code', 'N/A')
            withdrawal['stock_remaining'] = product.get('quantity', 'N/A')
        else:
            withdrawal['part_number'] = 'N/A'
            withdrawal['stock_remaining'] = 'N/A'
    return render_template('history.html', withdrawals=withdrawals)

@app.route('/edit-product/<id>', methods=['GET', 'POST'])
def edit_product(id):
    product = db.products.find_one({'_id': ObjectId(id)})

    if request.method == 'POST':
        name = request.form['name']
        code = request.form['code']
        quantity = int(request.form['quantity'])
        cost_center = request.form['cost_center']  # รับข้อมูล Cost Center

        db.products.update_one(
            {'_id': ObjectId(id)},
            {'$set': {
                'name': name,
                'code': code,
                'quantity': quantity,
                'cost_center': cost_center  # อัปเดต Cost Center
            }}
        )
        return redirect(url_for('products'))

    return render_template('edit_product.html', product=product)

@app.route('/delete-product/<id>', methods=['POST'])
def delete_product(id):
    db.products.delete_one({'_id': ObjectId(id)})
    return redirect(url_for('products'))

@app.route('/products-edit')
def products_edit():
    products = list(db.products.find())
    return render_template('products_edit.html', products=products)

if __name__ == '__main__':
    app.run(debug=True)