from flask import Flask, render_template, request, redirect, url_for, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId
import os

# Initialize Flask app
app = Flask(__name__)

# MongoDB connection
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
DB_NAME = os.getenv("DB_NAME", "inventory_db")
UPLOAD_FOLDER = "static/images"

client = MongoClient(MONGO_URI)
db = client[DB_NAME]

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def init_db():
    db.products.create_index('code', unique=True)
    db.withdrawals.create_index('date')
    db.withdrawals.create_index('product_id')


init_db()

# Routes
@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/products')
def products():
    page = request.args.get('page', 1, type=int)
    per_page = 15  # Updated the number of products per page to 15
    search_query = request.args.get('search', '').strip()
    cost_center = request.args.get('cost_center', '').strip()

    query = {}
    if search_query:
        query['name'] = {'$regex': search_query, '$options': 'i'}
    if cost_center:
        query['cost_center'] = cost_center

    total_products = db.products.count_documents(query)
    products = list(db.products.find(query).skip((page - 1) * per_page).limit(per_page))

    # Fetch all cost centers for the dropdown
    cost_centers = list(db.cost_centers.find())

    pagination = {
        'page': page,
        'per_page': per_page,
        'total': total_products,
        'has_prev': page > 1,
        'has_next': page * per_page < total_products,
        'prev_num': page - 1 if page > 1 else None,
        'next_num': page + 1 if page * per_page < total_products else None,
        'iter_pages': list(range(1, (total_products // per_page) + 2))
    }

    return render_template('products.html', products=products, pagination=pagination, cost_center=cost_center, cost_centers=cost_centers, search_query=search_query)

@app.route('/add-product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        code = request.form['code']
        quantity = int(request.form['quantity'])
        location = request.form['location']
        cost_center = request.form['cost_center']  # รับข้อมูล Cost Center

        # Handle image upload
        image = request.files.get('image')
        if image and image.filename:
            image_path = f"{UPLOAD_FOLDER}/{image.filename}"
            image.save(image_path)
        else:
            image_path = "static/images/default.png"  # Default image if none uploaded

        # Check if the cost center is new and add it to the cost_centers collection
        if not db.cost_centers.find_one({'name': cost_center}):
            db.cost_centers.insert_one({'name': cost_center})

        try:
            db.products.insert_one({
                'name': name,
                'code': code,
                'quantity': quantity,
                'location': location,
                'image': image_path,
                'cost_center': cost_center  # บันทึก Cost Center ลงฐานข้อมูล
            })
        except Exception as e:
            return f"Unable to save product: {str(e)}", 400

        return redirect(url_for('products'))

    return render_template('add_product.html')

@app.route('/withdraw/<id>', methods=['GET', 'POST'])
def withdraw(id):
    try:
        print(f"[DEBUG] Received ID: {id}")  # Debugging ID
        if not ObjectId.is_valid(id):
            print("[ERROR] Invalid ObjectId")
            return "Invalid Product ID!", 400

        product = db.products.find_one({'_id': ObjectId(id)})
        if not product:
            print("[ERROR] Product not found in database")
            return "Product not found!", 404

        error_message = None

        if request.method == 'POST':
            try:
                quantity = request.form.get('quantity')
                line = request.form.get('line')
                employee_id = request.form.get('employee_id')
                employee_name = request.form.get('employee_name')
                group = request.form.get('group')
                date = request.form.get('date')

                if not all([quantity, line, employee_id, employee_name, group, date]):
                    error_message = "Please fill in all fields."
                    print("[ERROR] Missing form data")
                    return render_template('withdraw.html', product=product, error_message=error_message)

                quantity = int(quantity)
                if product['quantity'] >= quantity:
                    db.products.update_one({'_id': ObjectId(id)}, {'$inc': {'quantity': -quantity}})
                    db.withdrawals.insert_one({
                        'product_id': id,
                        'product_name': product['name'],
                        'part_number': product.get('code', 'N/A'),
                        'cost_center': product.get('cost_center', 'N/A'),
                        'quantity': quantity,
                        'line': line,
                        'employee_id': employee_id,
                        'employee_name': employee_name,
                        'group': group,
                        'date': date
                        
                    })
                    print("[INFO] Withdrawal successful")
                    return redirect(url_for('history'))  # Redirect to history after withdrawal
                else:
                    error_message = "Not enough stock!"
                    print("[ERROR] Not enough stock")

            except ValueError:
                error_message = "Invalid input. Please check your data."
                print("[ERROR] Invalid input")

        return render_template('withdraw.html', product=product, error_message=error_message)

    except Exception as e:
        print(f"[ERROR] An exception occurred: {str(e)}")
        return f"An error occurred: {str(e)}", 500

@app.route('/history', methods=['GET'])
def history():
    # Get search parameters from the request
    product_name = request.args.get('product_name', '').strip()
    part_number = request.args.get('part_number', '').strip()
    line = request.args.get('line', '').strip()
    cost_center = request.args.get('cost_center', '').strip()
    date = request.args.get('date', '').strip()

    # Build the query dynamically based on provided search parameters
    query = {}
    if product_name:
        query['product_name'] = {'$regex': product_name, '$options': 'i'}
    if part_number:
        query['part_number'] = {'$regex': part_number, '$options': 'i'}
    if line:
        query['line'] = {'$regex': line, '$options': 'i'}
    if cost_center:
        query['cost_center'] = {'$regex': cost_center, '$options': 'i'}
    if date:
        query['date'] = date

    # Pagination logic
    page = request.args.get('page', 1, type=int)
    per_page = 30
    total_withdrawals = db.withdrawals.count_documents(query)
    withdrawals = list(db.withdrawals.find(query).sort('date', -1).skip((page - 1) * per_page).limit(per_page))

    # Ensure stock_remaining is included in the withdrawals data
    for withdrawal in withdrawals:
        product = None
        product_id = withdrawal.get('product_id')
        if product_id and ObjectId.is_valid(product_id):
            product = db.products.find_one({'_id': ObjectId(product_id)})

        if product:
            withdrawal['part_number'] = product.get('code', 'N/A')
            withdrawal['stock_remaining'] = product.get('quantity', 'N/A')
            withdrawal['cost_center'] = product.get('cost_center', withdrawal.get('cost_center', 'N/A'))
        else:
            withdrawal['part_number'] = withdrawal.get('part_number', 'N/A')
            withdrawal['stock_remaining'] = 'N/A'
            withdrawal['cost_center'] = withdrawal.get('cost_center', 'N/A')

    pagination = {
        'page': page,
        'per_page': per_page,
        'total': total_withdrawals,
        'has_prev': page > 1,
        'has_next': page * per_page < total_withdrawals,
        'prev_num': page - 1 if page > 1 else None,
        'next_num': page + 1 if page * per_page < total_withdrawals else None,
        'iter_pages': list(range(1, (total_withdrawals // per_page) + 2))
    }

    return render_template('history.html', withdrawals=withdrawals, 
                           product_name=product_name, part_number=part_number, 
                           line=line, cost_center=cost_center, date=date,
                           pagination=pagination)

@app.route('/edit-product/<id>', methods=['GET', 'POST'])
def edit_product(id):
    product = db.products.find_one({'_id': ObjectId(id)})

    if request.method == 'POST':
        name = request.form['name']
        code = request.form['code']
        quantity = int(request.form['quantity'])
        location = request.form['location']
        cost_center = request.form['cost_center']  # รับข้อมูล Cost Center

        image_path = product.get('image', 'static/images/default.png')
        image = request.files.get('image')
        if image and image.filename:
            image_path = f"{UPLOAD_FOLDER}/{image.filename}"
            image.save(image_path)

        db.products.update_one(
            {'_id': ObjectId(id)},
            {'$set': {
                'name': name,
                'code': code,
                'quantity': quantity,
                'location': location,
                'image': image_path,
                'cost_center': cost_center  # อัปเดต Cost Center
            }}
        )
        return redirect(url_for('products'))

    return render_template('edit_product.html', product=product)

@app.route('/delete-product/<id>', methods=['POST'])
def delete_product(id):
    db.products.delete_one({'_id': ObjectId(id)})
    return redirect(url_for('products'))

@app.route('/products-edit', methods=['GET'])
def products_edit():
    page = request.args.get('page', 1, type=int)
    per_page = 15
    cost_center = request.args.get('cost_center', '').strip()
    query = {}
    if cost_center:
        query['cost_center'] = cost_center

    total_products = db.products.count_documents(query)
    products = list(db.products.find(query).skip((page - 1) * per_page).limit(per_page))

    pagination = {
        'page': page,
        'per_page': per_page,
        'total': total_products,
        'has_prev': page > 1,
        'has_next': page * per_page < total_products,
        'prev_num': page - 1 if page > 1 else None,
        'next_num': page + 1 if page * per_page < total_products else None,
        'iter_pages': list(range(1, (total_products // per_page) + 2))
    }

    return render_template('products_edit.html', products=products, pagination=pagination)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')