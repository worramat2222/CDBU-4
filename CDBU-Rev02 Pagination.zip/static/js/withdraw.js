document.addEventListener('DOMContentLoaded', () => {
    const withdrawButtons = document.querySelectorAll('.withdraw-button');

    withdrawButtons.forEach(button => {
        button.addEventListener('click', (event) => {
            event.preventDefault();

            const productId = button.dataset.productId;
            const productName = button.dataset.productName;

            const quantity = prompt(`Enter quantity to withdraw for ${productName}:`);

            if (quantity && !isNaN(quantity) && quantity > 0) {
                const confirmWithdraw = confirm(`Are you sure you want to withdraw ${quantity} of ${productName}?`);

                if (confirmWithdraw) {
                    fetch(`/withdraw/${productId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ quantity: parseInt(quantity) })
                    })
                    .then(response => {
                        if (response.ok) {
                            alert('Withdrawal successful!');
                            location.reload();
                        } else {
                            alert('Error: Unable to withdraw.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred. Please try again.');
                    });
                }
            } else {
                alert('Invalid quantity entered.');
            }
        });
    });
});